var searchData=
[
  ['saverplayer_55',['SaverPlayer',['../class_entity_1_1_saver_player.html',1,'Entity']]],
  ['slugger_56',['Slugger',['../class_entity_1_1_enemies_1_1_slugger.html',1,'Entity::Enemies']]]
];
