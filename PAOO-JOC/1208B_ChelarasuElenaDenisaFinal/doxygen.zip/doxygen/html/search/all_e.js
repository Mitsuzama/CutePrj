var searchData=
[
  ['saverplayer_25',['SaverPlayer',['../class_entity_1_1_saver_player.html',1,'Entity']]],
  ['slugger_26',['Slugger',['../class_entity_1_1_enemies_1_1_slugger.html',1,'Entity::Enemies']]]
];
