var searchData=
[
  ['nivel1_19',['Nivel1',['../class_game_state_1_1_nivel1.html',1,'GameState']]],
  ['nivel2_20',['Nivel2',['../class_game_state_1_1_nivel2.html',1,'GameState']]],
  ['nivel3_21',['Nivel3',['../class_game_state_1_1_nivel3.html',1,'GameState']]]
];
