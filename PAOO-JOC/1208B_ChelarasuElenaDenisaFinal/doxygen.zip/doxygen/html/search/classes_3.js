var searchData=
[
  ['database_34',['DataBase',['../class_sql_database_1_1_data_base.html',1,'SqlDatabase']]]
];
